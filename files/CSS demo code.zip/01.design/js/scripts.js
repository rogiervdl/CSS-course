jQuery(document).ready(function () {
    jQuery('#banner').slick({
        arrows: false,
        dots: true,
        slidesToShow: 3,
        infinite: true
    });
});